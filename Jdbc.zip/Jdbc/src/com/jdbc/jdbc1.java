package com.jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class jdbc1 {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","dell1234");
//			Statement stmt= con.createStatement();
			/*String query1="select * from emp123";
			
			ResultSet result=stmt.executeQuery(query1);
			while(result.next())
			{
		
				System.out.println(result.getInt(1)+"     "+result.getString(2));
				
			}*/
			
//			String query2="insert into emp123 values(3,'ganesh')";
//			int res=stmt.executeUpdate(query2);
//			System.out.println(res);
			
			
//			String query3="update emp123 set name='vishal' where id=3";
//			int res1=stmt.executeUpdate(query3);
//			System.out.println(res1);
			
//			String query4="delete from emp123 where id=3";
//			int res=stmt.executeUpdate(query4);
//			System.out.println(res);
			
			PreparedStatement stmt=con.prepareStatement("insert into emp123 values(?,?)");
			stmt.setInt(1, sc.nextInt());
			stmt.setString(2, sc.next());
			int res=stmt.executeUpdate();
			System.out.println(res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

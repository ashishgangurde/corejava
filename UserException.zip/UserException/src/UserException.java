import java.util.Scanner;

public class UserException extends Exception {
	
	public UserException (String s)
	{
		super(s);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("Enter marks plz");
		int marks=sc.nextInt();
		if(marks<0)
		{
			throw new UserException("Lavdya nit tak");
		}
		}
		catch(UserException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
}

package com.serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class test {

	public static void main(String[] args) {
		
		employee e1=new employee(1,"lalit", 50000);
		employee e2=new employee(2,"pravin", 40000);
		employee e3=new employee(3,"akshay", 45000);
		ArrayList<employee> arr= new ArrayList<employee>();
		arr.add(e1);
		arr.add(e2);
		arr.add(e3);
		
		try {
			FileOutputStream fs= new FileOutputStream("C:/Users/Lalit/source/repos/avjadhav/ag.txt");
			ObjectOutputStream os=new ObjectOutputStream(fs);
			os.writeObject(arr);
			fs.close();
			os.close();
			System.out.println("serialization successfully done");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("--------deserialization------------");
		
		try {
			FileInputStream fsi=new FileInputStream("C:/Users/Lalit/source/repos/avjadhav/ag.txt");
			ObjectInputStream osi=new ObjectInputStream(fsi);
			ArrayList<employee> a1=new ArrayList<>();
			a1= (ArrayList<employee>) osi.readObject();
			
			for (employee e : a1) 
			{
				System.out.println(e.toString());
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
}

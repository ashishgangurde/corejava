package solution1;

import java.util.*;

public class RollCompare implements Comparator<student> {

	@Override
	public int compare(student s1, student s2) {
		if(s1.rollno==s2.rollno)  
			return 0;  
			else if(s1.rollno>s2.rollno)  
			return 1;  
			else  
			return -1;
		
	}
	
	
	

}

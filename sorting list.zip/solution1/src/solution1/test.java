package solution1;

import java.util.Collections;
import java.util.TreeSet;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student("Akshay",101,"latur",90);
		student s2=new student("vishal",151,"latur",90);
		student s3=new student("shish",123,"latur",90);
		
		TreeSet<student> t1= new TreeSet<>();
		t1.add(s1);
		
		t1.add(s2);
		t1.add(s3);
		
		
		System.out.println("Sorting by Name");  
		//Using NameComparator to sort the elements  
		Collections.sort(t1,new nameCompare());  
		//Traversing the elements of list  
		for(student st: tl){  
		System.out.println(st.toString());  
		}  
		
		
		
		System.out.println("sorting by Age");  
		//Using AgeComparator to sort the elements  
		Collections.sort(t1,new RollCompare());  
		//Travering the list again  
		for(Student st: al){  
		System.out.println(st.rollno+" "+st.name+" "+st.age);  
		}  
		
	}

}

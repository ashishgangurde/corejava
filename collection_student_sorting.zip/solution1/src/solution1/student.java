package solution1;

import java.util.Comparator;

public class student implements Comparable<student>{
	public String name;
	public int rollno;
	public String city;
	public int marks;
	public student(String name, int rollno, String city, int marks) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.city = city;
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "student [name=" + name + ", rollno=" + rollno + ", city=" + city + ", marks=" + marks + "]";
	}
	@Override
	public int compareTo(student s) {
	 student s2=(student)s;
	 
	 return this.rollno-s2.rollno;
		
	}
	
	
	
	
	

}

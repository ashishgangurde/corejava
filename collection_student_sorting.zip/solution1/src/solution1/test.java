package solution1;

import java.util.TreeSet;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student("Akshay",101,"latur",90);
		student s2=new student("vishal",151,"latur",90);
		student s3=new student("shish",123,"latur",90);
		
		TreeSet<student> t1= new TreeSet<>();
		t1.add(s1);
		
		t1.add(s2);
		t1.add(s3);
		
		
		System.out.println(t1.toString());
		
		
		
	}

}

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class WriteFile {
	
	
	//Create a  New file and writing String 
	
	
	/*public static void main(String args[]){    
        try{    
          FileOutputStream fout=new FileOutputStream("E:/Adv Java/workspace/myfile.txt");    
          String s="Welcome to javaTpoint.";    
          byte b[]=s.getBytes();//converting string into byte array    
          fout.write(b);    
          fout.close();    
          System.out.println("success...");    
         }catch(Exception e){System.out.println(e);}    
   }    */
	
	
	//Reading String from file
	
	/*public static void main(String args[]){    
        try{    
          FileInputStream fin=new FileInputStream("E:/Adv Java/workspace/myfile.txt");    
          int i=0;    
          while((i=fin.read())!=-1){    
           System.out.print((char)i);    
          }    
          fin.close();    
        }catch(Exception e){System.out.println(e);}    
       } */   
	
	//Writing Buffer output Stream
	
	/*public static void main(String args[])throws Exception{    
	     FileOutputStream fout=new FileOutputStream("E:/Adv Java/workspace/myfile1.txt");    
	     BufferedOutputStream bout=new BufferedOutputStream(fout);    
	     String s="Welcome to javaTpoint.";    
	     byte b[]=s.getBytes();    
	     bout.write(b);    
	     bout.flush();    
	     bout.close();    
	     fout.close();    
	     System.out.println("success");   */ 
	
	
	//Reading Buffer Input Stream
	
	/*public static void main(String args[]){    
		  try{    
		    FileInputStream fin=new FileInputStream("E:/Adv Java/workspace/myfile1.txt");    
		    BufferedInputStream bin=new BufferedInputStream(fin);    
		    int i;    
		    while((i=bin.read())!=-1){    
		     System.out.print((char)i);    
		    }    
		    bin.close();    
		    fin.close();    
		  }catch(Exception e){System.out.println(e);}    
		 }    */
//	Concat data of two files
//FileInputStream input1=new FileInputStream("D:\\testin.txt");   
// FileInputStream input2=new FileInputStream("D:\\testout.txt");  
//   SequenceInputStream inst=new SequenceInputStream(input1, input2);  
	
	


}    
	
	


